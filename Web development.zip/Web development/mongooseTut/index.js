const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/abhiKart', {useNewUrlParser: true, useUnifiedTopology: true});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
  // we're connected!
  console.log("We are connected bro")
});

const kittySchema = new mongoose.Schema({
    name: String
  });

  kittySchema.methods.speak = function () {
    const greeting = this.name
      ? "Meow name is " + this.name
      : "I don't have a name";
    console.log(greeting);
  }

  const Kitten = mongoose.model('test', kittySchema);

  var abhiKitty = new Kitten({name :"mongoDBTutorial"});
  console.log(abhiKitty.name);
  abhiKitty.speak();

  abhiKitty.save(function (err, abhiKitty) {
    if (err) return console.error(err);
    abhiKitty.speak();
  });

  Kitten.find({name:"mongoDBTutorial"},function (err, kittens) {
    if (err) return console.error(err);
    console.log(kittens);
  })