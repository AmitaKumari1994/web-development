//Inserting data in mongodb
use abhiKart;

db.items.insertOne({"name":"samsung 40 s",price:22000,rating:3.9,quantity:800,sold:1600});
db.items.insertMany([{"name":"motog 40 s",price:12000,rating:3.1,quantity:80,sold:1600},{"name":"realme pro",price:122000,rating:1.9,quantity:800,sold:10},{"name":"iphone",price:122000,rating:4.9,quantity:800,sold:500}])

//return items with rating 3.9
db.items.find({rating:3.9})

//returns items with rating greater than 3.5 and price 4000
db.items.find({rating:{$gt:3.5} , price:{$gt:4000}})

//update items in db first parameter is fileter and second is to update the required tag
db.items.updateOne({name :"motog 40 s"},{$set:{price:2}})
