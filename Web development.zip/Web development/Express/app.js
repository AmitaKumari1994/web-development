const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();
const port = 80;

//EXPRESS SPECIFIC STUFF
app.use('/static', express.static('static')); //For serving static files
app.use(express.urlencoded());

// PUG SPECIFIC STUFF
app.set('view engine', 'pug') //set the template engine as pug
app.set('views', path.join(__dirname, 'views'));  //set the views directory


//Our pug demo endpoint
// app.get("/demo",(req, res)=>{
//     res.status(200).render('demo',{title: 'Hey Harry', message: 'Hello there and thanks for telling me how to use pubg'});
// });

// app.get("/about",(req, res)=>{
//     res.status(200).send("This is my about page of express app with harry")
// });

// app.get("/contacts",(req, res)=>{
//     res.send("This is my contact page of express app with harry")
// });

// app.post("/this",(req, res)=>{
//     res.status(404).send("This page is not found on my website")
// });

// ENDPOINTS
app.get('/', (req, res) => {
    const con = "This is the best content on the internet so far so use it wisely";
    const params = { 'title': 'PubG is the best game', "content": con }
    res.status(200).render('index.pug', params);
})

app.post('/', (req, res) => {
    console.log(req.body);
    name = req.body.name;
    age = req.body.age;
    gender = req.body.gender;
    address = req.body.address;
    more = req.body.more;

    let outPutToWrite = `The name of the client is ${name}. The age of the client is ${age} . Client's gender is ${gender} . Address is ${address}. More about our client is ${more}`;
    
    fs.writeFileSync(`${name}.txt`,outPutToWrite);
    const params = { 'message': 'Your form has been submitted successfully' };
    res.status(200).render('index.pug', params);

})

app.listen(port, () => {
    console.log(`The application started successfully on ${port}`)
});

