//Inserting data in mongo DB

use abhiKart

//for items having the rating greater than or equal to 3.5

db.items.find({rating: {$gte:3.5}})

//for items rating greater than 3.5 AND price less than 14000

db.items.find({rating:{$gte:3.5},price:{$lt:14000}})

//OR syntac in  mongodb
db.items.find({$or:[{rating:{$gt:3.5}},{price:{$gt:3000}}]})

//delete items from database
db.items.deleteOne({price:22000})
//delete the first matched entry from db

//delete many matching items
db.itemns.deleteMany({price:25000})

//